<?php
// Generate Key and Salt from
// https://upigateway.com/user/api_credentials

$key = "06f9c14c-b06c-4443-a0da-ff0923eb0951";
$salt = "r-l41D2RhEvkVHcagkWYs";
// Redirect to below url after the transaction is Process.
$redirect_url = "http://35.154.176.14/thankyou.php";

// All Transaction Updates is given using Webhooks (callback)
// Please set webhook at https://upigateway.com/user/api_credentials

if(isset($_POST['client_vpa'])){
	try {
		header('Content-Type: application/json');

		$client_vpa = $_POST['client_vpa'];
		$amount = $_POST['amount'];
		$client_name = $_POST['client_name'];
		$client_email = $_POST['client_email'];
		$client_mobile = $_POST['client_mobile'];
		$client_txn_id = $_POST['client_txn_id'];
		$udf1 = $_POST['udf1'];
		$udf2 = $_POST['udf2'];
		$udf3 = $_POST['udf3'];
		$p_info = $_POST['p_info'];
	
		$hash = hash('SHA512', "{$key}|{$client_vpa}|{$client_txn_id}|{$amount}|{$p_info}|{$client_name}|{$client_email}|{$client_mobile}|{$udf1}|{$udf2}|{$udf3}|{$salt}");
		die(json_encode(array("status"=>"Success", "hash"=>$hash)));
	} catch (\Throwable $th) {
		die(json_encode(array("status"=>"Error", "hash"=>"")));
	}
}

?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UPI Payment Page</title>
  <style>
  input{
    display:block;
    margin-bottom:10px;
  }
  label{
    margin-bottom:3px;
  }  
  </style>
</head>
<body>
  <form action="https://upigateway.com/gateway/payment" method="post" id="payment_form" style="visibility: hidden">
    <label for="client_vpa">
      Payee UPI :
    </label>
    <input type="text" name="client_vpa"  id="client_vpa" placeholder="Enter Payee UPI" value="<?= $_GET['upi'] ?>">

    <label for="amount">
      Amount :
    </label>
    <input type="text" name="amount" id="amount" placeholder="Enter Amount" value="<?= $_GET['amount'] ?>">

    <label for="client_name">
      Payee Name: 
    </label>
    <!-- client_name field also set hidden if you set value in hidden -->
    <input type="text" name="client_name" id="client_name" placeholder="Enter Payee Name" value="<?= $_GET['name'] ?>">

    <label for="client_email">
      Payee Email: 
    </label>
	<!-- client_email field also set hidden if you set value in hidden -->
    <input type="text" name="client_email" id="client_email" placeholder="Enter Payee Email" value="<?= $_GET['email'] ?>">

    <label for="client_mobile">
      Payee Mobile: 
    </label>
	<!-- client_mobile field also set hidden if you set value in hidden -->
    <input type="text" name="client_mobile" id="client_mobile" placeholder="Enter Payee Mobile" value="<?= $_GET['mobile'] ?>">
    <input type="hidden" name="key" value="<?php echo $key; ?>">

    <!-- p_info is used to Product Related Detail -->
    <input type="hidden" name="p_info" id="p_info" value="RECHARGE">

    <!-- client transactionID is unique string generate by your website or App. Transaction cannot processed again with same transactionID, we prefered to use UUID -->
    <!-- <input type="hidden" name="client_txn_id" id="client_txn_id" value="<?php echo uniqid().uniqid(); ?>"> -->
    <input type="hidden" name="client_txn_id" id="client_txn_id" value="<?= $_GET['name'] ?>">

    <!-- for recharge B2B Portal, you can use udf1 for user_id from which you will get the Money -->
    <input type="hidden" name="udf1" id="udf1" value="">
    <input type="hidden" name="udf2" id="udf2" value="">
    <input type="hidden" name="udf3" id="udf3" value="">

	<!-- hash is generate from above php code, with all above input field data and updated in hash field using javascript the form has to Submited to UPI Gateway. -->
    <input type="hidden" name="hash" value="" id="hash">
    
	<!-- Redirect url is not included in hash, put the complete url, it will redirect after the transaction Process is complete. -->
    <input type="hidden" name="redirect_url" value="<?php echo $redirect_url; ?>">
    <input type="submit" id="pay">Pay</button>
  </form>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script>
	var payment_form = document.getElementById("payment_form");
	payment_form.addEventListener("submit", function(e){
		e.preventDefault();
		var client_vpa = document.getElementById("client_vpa").value;
		var amount = document.getElementById("amount").value;
		var client_name = document.getElementById("client_name").value;
		var client_email = document.getElementById("client_email").value;
		var client_mobile = document.getElementById("client_mobile").value;
		var client_txn_id = document.getElementById("client_txn_id").value;
		var udf1 = document.getElementById("udf1").value;
		var udf2 = document.getElementById("udf2").value;
		var udf3 = document.getElementById("udf3").value;
		var p_info = document.getElementById("p_info").value;
		var hash = document.getElementById("hash");

		$.ajax({
			type: 'POST',
			url: 'pay.php',
			data: { client_vpa, amount, client_name, client_email, client_mobile, p_info, udf1, udf2, udf3, client_txn_id },
			json: true,
			success: function(data) {
				console.log(data);
				hash.value = data.hash;
				payment_form.submit();
			},
			error: function() {
				console.log("Hash was unsuccessful");
			}
		});
		return false;
	})
	document.getElementById('pay').click();

  </script>
</body>
</html>
